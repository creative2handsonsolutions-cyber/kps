// Sanitize user input before processing
function sanitizeInput(input) {
  return input.replace(/[<>]/g, '');
}

document.getElementById('applyForm').addEventListener('submit', function (e) {
  e.preventDefault();

  const name = sanitizeInput(document.getElementById('name').value.trim());
  const email = sanitizeInput(document.getElementById('email').value.trim());
  const message = sanitizeInput(document.getElementById('message').value.trim());
  const msg = document.getElementById('formMsg');

  if (!name || !email || !message) {
    msg.textContent = "All fields are required.";
    msg.style.color = "yellow";
    return;
  }

  msg.textContent = "Your application has been received successfully!";
  msg.style.color = "#00ffcc";

  this.reset();
});
